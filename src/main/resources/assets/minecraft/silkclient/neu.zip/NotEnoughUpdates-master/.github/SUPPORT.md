<!-- markdownlint-disable MD034 -->

# Obtain Support for NotEnoughUpdates

If you are struggling to install the mod, having issues with it, experiencing
unexpected crashes, or have another issue: join our community [discord server](https://discord.gg/moulberry)
and ask for help in the #neu-support channel.
